#ifndef __KEY_H__
#define __KEY_H__

void Key_Init(void);
void Key_Loop(void);

#endif
