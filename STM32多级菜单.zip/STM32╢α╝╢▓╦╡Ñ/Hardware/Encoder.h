#ifndef __ENCODER_H__
#define __ENCODER_H__

#include "stm32f10x.h"                  // Device header

void Encoder_Init(void);
void Encoder_Loop(void);

#endif
