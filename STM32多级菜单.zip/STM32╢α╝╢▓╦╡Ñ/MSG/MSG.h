#ifndef __MSG_H__
#define __MSG_H__

#include "stm32f10x.h"                  // Device header
#include "Message.h"





/*函数声明*********************/

void MSG_DefaultProc(MSG* msg);

/*********************函数声明*/





#endif
